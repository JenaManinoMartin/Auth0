# auth0_react_spa
React SPA with Auth0 and react-router-dom example project
