const CallbackPage = () => {
  return <div></div>;
};

export default CallbackPage;
