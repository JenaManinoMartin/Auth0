package com.example.auth0api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Auth0ApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
