package com.example.auth0api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Auth0ApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Auth0ApiApplication.class, args);
	}

}
